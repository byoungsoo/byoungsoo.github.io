#!/usr/bin/env bash

readonly waitTime='15s'

# appspec upload
aws s3 cp cicd/codedeploy/appspec.yaml s3://$s3_bucket/artifacts/

# execute codedeploy
codedeployId=$(aws deploy create-deployment \
    --cli-input-json file://cicd/codedeploy/create-deployment.json \
    --region ap-northeast-2 | jq -r '.deploymentId')

echo $codedeployId
aws deploy get-deployment --deployment-id $codedeployId

getDeployStatus(){
    deployStatus=$(aws deploy get-deployment --deployment-id $codedeployId | jq -r '.deploymentInfo.status')

    echo "CodeDeploy $codedeployId, current status: $deployStatus"
}

getDeployStatus

while [[ $deployStatus == "InProgress" ]] || [[ $deployStatus == "Created" ]]
do
    echo "Sleeping for $waitTime to allow the deploy progress to complete."
    sleep $waitTime
    getDeployStatus
done

if [[ $deployStatus == 'Succeeded' ]]; then
    exit 0
else
    exit 1
fi
