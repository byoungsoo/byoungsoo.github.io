#!/usr/bin/env bash

readonly waitTime='15s'

# buildspec upload
zip -j $source_artifact ./cicd/codebuild/*
aws s3 cp $source_artifact s3://$s3_bucket/artifacts/

codebuild=$(echo $codebuild | tr [a-z] [A-Z])

# execute codebuild
codebuildId=$(aws codebuild start-build --project-name $codebuild | jq -r '.build.id')

echo $codebuildId
aws codebuild batch-get-builds --ids $codebuildId

# check codebuild
getCodeBuildStatus(){
    codbuildStatus=$(aws codebuild batch-get-builds --ids $codebuildId | jq -r '.builds[0].buildStatus')

    echo "CodeBuild $codebuild, current status: $codbuildStatus (non-existent if blank)"
}

# Get the status of the CFN stack that will be deployed
getCodeBuildStatus

# Wait until the stack status is no longer IN_PROGRESS
while [[ $codbuildStatus == *"IN_PROGRESS"* ]]
do
    echo "Sleeping for $waitTime to allow the codebuild progress to complete."
    sleep $waitTime
    getCodeBuildStatus
done

if [[ $codbuildStatus == 'SUCCEEDED' ]]; then
    exit 0
else
    exit 1
fi

