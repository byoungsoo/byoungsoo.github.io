
package com.kbcard.ubd.UBDcommon;

import com.kbcard.ubd.cpbi.cmn.UBD_CONST;

import devon.core.collection.LData;
import devon.core.exception.DevonException;
import devon.core.exception.LException;
import devon.core.util.LNullUtils;
import devonenterprise.ext.util.ContextUtil;
import devonenterprise.ext.util.StringUtil;
import devonframework.persistent.autodao.LCommonDao;

public class MainCommon {

	
}
